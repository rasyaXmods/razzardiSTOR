import { db } from "@/lib/db";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function GET(_request: Request, context: { params: Promise<{ publicId: string }> }) {
  const { publicId } = await context.params;
  const order = await db.order.findUnique({
    where: { publicId },
    select: {
      publicId: true, status: true, amount: true, createdAt: true,
      product: { select: { name: true } }
    }
  });
  if (!order) return jsonError("Pesanan tidak ditemukan.", 404);
  return Response.json({ order });
}
