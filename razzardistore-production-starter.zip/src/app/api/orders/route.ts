import { randomUUID } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { snapClient } from "@/lib/midtrans";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

const schema = z.object({
  productId: z.string().min(1),
  playerId: z.string().trim().min(1).max(80),
  playerZone: z.string().trim().max(40).optional(),
  customerEmail: z.string().email().optional()
});

export async function POST(request: Request) {
  let data: z.infer<typeof schema>;
  try { data = schema.parse(await request.json()); }
  catch { return jsonError("Data pesanan tidak valid."); }

  const product = await db.product.findFirst({
    where: { id: data.productId, active: true }
  });
  if (!product) return jsonError("Produk tidak ditemukan atau sedang tidak aktif.", 404);

  // Prices are always read from the database, never trusted from the browser.
  const publicId = `RZ-${randomUUID().replaceAll("-", "").slice(0, 16).toUpperCase()}`;
  const idempotencyKey = randomUUID();
  const order = await db.order.create({
    data: {
      publicId, productId: product.id, playerId: data.playerId,
      playerZone: data.playerZone, customerEmail: data.customerEmail,
      amount: product.price, idempotencyKey
    }
  });

  try {
    const snap = snapClient();
    const transaction = await snap.createTransaction({
      transaction_details: { order_id: order.publicId, gross_amount: order.amount },
      item_details: [{ id: product.providerSku, price: product.price, quantity: 1, name: product.name.slice(0, 50) }],
      customer_details: data.customerEmail ? { email: data.customerEmail } : undefined,
      callbacks: { finish: `${process.env.APP_BASE_URL}/cek-pesanan?id=${order.publicId}` }
    });
    await db.order.update({
      where: { id: order.id },
      data: { paymentToken: transaction.token, paymentReference: order.publicId }
    });
    await db.orderEvent.create({
      data: { orderId: order.id, source: "system", eventType: "PAYMENT_SESSION_CREATED" }
    });
    return Response.json({ orderId: order.publicId, paymentToken: transaction.token });
  } catch (error) {
    await db.order.update({ where: { id: order.id }, data: { status: "FAILED" } });
    await db.orderEvent.create({
      data: { orderId: order.id, source: "system", eventType: "PAYMENT_SESSION_FAILED",
        detail: { message: error instanceof Error ? error.message : "Unknown error" } }
    });
    return jsonError("Pembayaran belum dapat dibuat. Silakan coba lagi.", 502);
  }
}
