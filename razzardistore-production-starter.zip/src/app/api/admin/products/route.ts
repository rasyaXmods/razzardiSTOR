import { z } from "zod";
import { db } from "@/lib/db";
import { jsonError, requireAdmin } from "@/lib/http";

export const runtime = "nodejs";
const schema = z.object({
  slug: z.string().min(2).max(80),
  name: z.string().min(2).max(100),
  category: z.string().min(2).max(60),
  providerSku: z.string().min(2).max(100),
  price: z.number().int().positive(),
  active: z.boolean().optional()
});

export async function GET(request: Request) {
  if (!requireAdmin(request)) return jsonError("Unauthorized", 401);
  const products = await db.product.findMany({ orderBy: { createdAt: "desc" } });
  return Response.json({ products });
}

export async function POST(request: Request) {
  if (!requireAdmin(request)) return jsonError("Unauthorized", 401);
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return jsonError("Data produk tidak valid.");
  const product = await db.product.create({ data: parsed.data });
  return Response.json({ product }, { status: 201 });
}

export async function PATCH(request: Request) {
  if (!requireAdmin(request)) return jsonError("Unauthorized", 401);
  const body = await request.json().catch(() => null);
  if (!body || typeof body.id !== "string") return jsonError("ID produk wajib diisi.");
  const parsed = schema.partial().safeParse(body);
  if (!parsed.success) return jsonError("Data produk tidak valid.");
  const { id: _ignored, ...data } = parsed.data as typeof parsed.data & { id?: string };
  const product = await db.product.update({ where: { id: body.id }, data });
  return Response.json({ product });
}
